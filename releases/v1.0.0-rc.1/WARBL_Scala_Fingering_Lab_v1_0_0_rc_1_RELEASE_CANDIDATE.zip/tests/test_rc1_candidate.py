from playwright.sync_api import sync_playwright
import json,re,math,sys,pathlib,statistics
html='/mnt/data/WARBL_Scala_Fingering_Lab_v1_0_0_rc_1.html'
scala_path='/mnt/data/FirstideaTarsos.scl'
results=[]
def check(name,cond,detail=None):
    results.append({'name':name,'status':'PASS' if cond else 'FAIL','detail':detail})
    if not cond: print('FAIL',name,detail)

txt=pathlib.Path(html).read_text(encoding='utf8')
m=re.search(r'<script(?:\s[^>]*)?>(.*?)</script>',txt,re.S|re.I)
assert m
# Instrument click listener registration before app code loads.
listener_init=r'''(() => {
  const orig=EventTarget.prototype.addEventListener;
  EventTarget.prototype.addEventListener=function(type,listener,opts){
    try { if(type==='click' && this instanceof HTMLElement){ this.dataset.__clickListenerCount=String((Number(this.dataset.__clickListenerCount)||0)+1); } } catch(e) {}
    return orig.call(this,type,listener,opts);
  };
  let requestCount=0;
  try { Object.defineProperty(window,'isSecureContext',{configurable:true,value:true}); } catch(e) {}
  class MockPort { constructor(id,name,type){this.id=id;this.name=name;this.manufacturer='Mowry Stringed Instruments';this.type=type;this.state='connected';this.connection='closed';this.onmidimessage=null;this.sent=[];} async open(){this.connection='open';return this;} async close(){this.connection='closed';return this;} send(data){this.sent.push(Array.from(data));} }
  const input=new MockPort('warbl-in','WARBL MIDI 1','input'); const output=new MockPort('warbl-out','WARBL MIDI 1','output');
  const access={inputs:new Map([[input.id,input]]),outputs:new Map([[output.id,output]]),onstatechange:null};
  Object.defineProperty(navigator,'requestMIDIAccess',{configurable:true,value:async()=>{requestCount++;return access;}});
  try { Object.defineProperty(navigator,'permissions',{configurable:true,value:{query:async()=>({state:'granted',onchange:null})}}); } catch(e) {}
  const downloads=[]; const anchorClicks=[];
  const oldCreate=URL.createObjectURL.bind(URL); URL.createObjectURL=(blob)=>{downloads.push({size:blob?.size||0,type:blob?.type||''}); return oldCreate(blob);};
  const oldAnchor=HTMLAnchorElement.prototype.click; HTMLAnchorElement.prototype.click=function(){anchorClicks.push({download:this.download||'',href:this.href||''}); return oldAnchor.call(this);};
  let printCount=0; window.print=()=>{printCount++;};
  let clipboard=[]; try{Object.defineProperty(navigator,'clipboard',{configurable:true,value:{writeText:async(t)=>{clipboard.push(String(t));}}});}catch(e){}
  window.__gate={access,input,output,getRequestCount:()=>requestCount,downloads,anchorClicks,getPrintCount:()=>printCount,clipboard};
})();'''
with sync_playwright() as p:
  browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--autoplay-policy=no-user-gesture-required'])
  page=browser.new_page(viewport={'width':1440,'height':1000},accept_downloads=True)
  errors=[]; console_errors=[]
  page.on('pageerror',lambda e: errors.append(str(e)))
  page.on('console',lambda msg: console_errors.append(msg.text) if msg.type=='error' else None)
  page.set_content(txt[:m.start()]+'<script></script>'+txt[m.end():],wait_until='load',timeout=60000)
  page.evaluate(listener_init)
  page.add_script_tag(content=m.group(1)); page.wait_for_timeout(600)
  dbg='window.WARBLScalaFingeringLaboratoryDebug'
  check('C01 page starts without JavaScript errors',not errors,errors)
  check('C02 v1.0.0-rc.1 identity present','v1.0.0-rc.1' in page.locator('footer.app-footer').inner_text())
  # Complete button wiring inventory.
  inv=page.evaluate('''() => Array.from(document.querySelectorAll('button')).map((b,i)=>({i,id:b.id||null,text:(b.textContent||'').trim().replace(/\\s+/g,' ').slice(0,100),disabled:b.disabled,hidden:b.hidden,listenerCount:Number(b.dataset.__clickListenerCount||0),onclick:typeof b.onclick==='function'}))''')
  unwired=[b for b in inv if b['listenerCount']==0 and not b['onclick']]
  check('C03 all button elements have click wiring',len(inv)>=159 and len(unwired)==0,{'count':len(inv),'unwired':unwired[:20]})
  # Previously dead Extended controls produce effects.
  before=page.evaluate(f'{dbg}.getExtendedSystemsState()')
  page.evaluate("document.querySelector('#rebuildExtendedSystems').click()"); page.wait_for_timeout(80)
  after=page.evaluate(f'{dbg}.getExtendedSystemsState()')
  status_ext=page.evaluate("document.querySelector('#statusMessage').textContent")
  check('C04 Extended Generate/refresh systems is functional',after['generated'] and ('Extended fingering systems regenerated' in status_ext),{'before':before,'after':after,'status':status_ext})
  d0=page.evaluate('window.__gate.downloads.length')
  page.evaluate("document.querySelector('#exportExtendedGuide').click()"); page.wait_for_timeout(80)
  d1=page.evaluate('window.__gate.downloads.slice()')
  check('C05 Extended Download DAW workflow emits nonempty payload',len(d1)>d0 and d1[-1]['size']>100,d1[-1] if d1 else None)
  # Pattern/Practice family repaired.
  pat=page.evaluate(f"{dbg}.generatePattern({{type:'ascending',mode:'listen',articulation:'breath'}})")
  check('C06 Pattern Tutor generates a valid exercise',isinstance(pat,dict) and len(pat.get('steps') or [])>0,pat)
  # UI button Generate path should also work without error.
  page.evaluate("document.querySelector('#generatePattern').click()"); page.wait_for_timeout(80)
  pat2=page.evaluate(f'{dbg}.getPatternTutorState()')
  check('C07 Generate path UI remains functional',len(pat2.get('exercise',{}).get('steps',[]) if isinstance(pat2.get('exercise'),dict) else pat2.get('steps',[]) or [])>0 or bool(pat2.get('exercise')),pat2)
  # Export native exercise must produce a payload after valid exercise.
  d0=page.evaluate('window.__gate.downloads.length')
  if page.locator('#exportPattern').count(): page.evaluate("document.querySelector('#exportPattern').click()")
  elif page.locator('#exportNativeExercise').count(): page.evaluate("document.querySelector('#exportNativeExercise').click()")
  page.wait_for_timeout(80)
  d2=page.evaluate('window.__gate.downloads.slice()')
  check('C08 native exercise export produces payload',len(d2)>d0 and d2[-1]['size']>0,d2[-1] if len(d2)>d0 else {'availableIds':page.evaluate("Array.from(document.querySelectorAll('button')).filter(b=>/exercise/i.test(b.textContent)).map(b=>b.id+':'+b.textContent.trim())")})
  # Main export family remains functional.
  export_ids=['downloadScl','downloadKbm','downloadFieldScl','downloadPerformanceProfile','downloadFieldOperator','downloadSceneCapsule','downloadProfile','downloadMapping','downloadWarbl','downloadPackage']
  export_results=[]
  for bid in export_ids:
    loc=page.locator('#'+bid)
    if loc.count()==0: continue
    if loc.is_disabled(): continue
    pre=page.evaluate('window.__gate.downloads.length')
    try:
      page.evaluate('(id)=>document.getElementById(id).click()',bid); page.wait_for_timeout(700 if bid=='downloadPackage' else 120)
      arr=page.evaluate('window.__gate.downloads.slice()')
      export_results.append({'id':bid,'emitted':len(arr)>pre,'last':arr[-1] if len(arr)>pre else None})
    except Exception as e:
      export_results.append({'id':bid,'emitted':False,'error':str(e)})
  check('C09 principal export controls emit concrete payloads',all(x.get('emitted') and (x.get('last') or {}).get('size',0)>0 for x in export_results),export_results)
  # Connect and sensor states still work after control changes.
  page.evaluate("document.querySelector('#connectMidi').click()"); page.wait_for_timeout(180)
  conn=page.evaluate(f'{dbg}.getConnectionUi()')
  check('C10 Connect still opens MIDI and Live Sensors','Connected' in conn['midi'] and conn['sensors']=='Live Sensors: On',conn)
  # Post-blocking UI resync must explicitly request fresh raw state and recover when current bytes arrive.
  cfg_events=page.evaluate(f'{dbg}.attachMockWarblConfigOutput()')
  page.evaluate(f'{dbg}.setDebugToneState(6)'); page.wait_for_timeout(20)
  enter=page.evaluate(f"{dbg}.simulateBlockingUiEnter('print gate')")
  exitv=page.evaluate(f"{dbg}.simulateBlockingUiExit('print gate')")
  raw0=page.evaluate(f'{dbg}.getRawHoleCommitState()')
  sent=page.evaluate('state.warblConfigOutput ? true : false')
  # Re-report the currently held tone state 6 as a paired high/low report.
  mask=(6<<1)
  page.evaluate('(x)=>{handleWarblConfigMessage(0xB6,114,x.hi); handleWarblConfigMessage(0xB6,115,x.lo);}',{'hi':(mask>>7)&3,'lo':mask&127})
  page.wait_for_timeout(25)
  raw1=page.evaluate(f'{dbg}.getRawHoleCommitState()')
  check('C11 post-blocking exit requests a fresh raw-state handshake',bool(exitv.get('requiresFreshState')) and raw0['requiresFreshState'],{'exit':exitv,'raw0':raw0})
  check('C12 paired raw report resolves post-blocking fresh-state requirement',raw1['requiresFreshState'] is False and raw1['physicalDegreeKey'] is not None,raw1)
  # Reproduce the recovered.7 low-note race: current raw state ~26ms old, Note On, then new paired hole report arrives within sync window.
  # First return to normal lab-raw/reference.
  page.evaluate(f"{dbg}.setPerformanceSources('lab-raw','auto')")
  page.evaluate("state.playbackVoice='reference'; renderPlaybackVoice();")
  # Find one state for degree 4 and one for degree 6 under current scale.
  st=page.evaluate(f'{dbg}.getStates()')
  idx4=next((x['index'] for x in st if str(x.get('sourceDegreeKey'))=='4'),None)
  idx6=next((x['index'] for x in st if str(x.get('sourceDegreeKey'))=='6'),None)
  check('C13 low-note race fixture has degree-4 and degree-6 states',idx4 is not None and idx6 is not None,{'idx4':idx4,'idx6':idx6})
  if idx4 is not None and idx6 is not None:
    page.evaluate(f'{dbg}.setDebugToneState({idx4})'); page.evaluate(f'{dbg}.clearFlightRecorder(); {dbg}.startFlightRecorder()'); page.evaluate('state.live.lastHoleStateAt=performance.now()'); page.wait_for_timeout(26)
    mask6=(idx6<<1)
    race=page.evaluate('''async (x)=>{
      const p=handleMidiMessage({data:Uint8Array.from([0x92,57,110]),timeStamp:performance.now()});
      setTimeout(()=>handleWarblConfigMessage(0xB6,114,x.hi),2);
      setTimeout(()=>handleWarblConfigMessage(0xB6,115,x.lo),3);
      await p; await new Promise(r=>setTimeout(r,20));
      return {live:WARBLScalaFingeringLaboratoryDebug.getLiveState(), fr:WARBLScalaFingeringLaboratoryDebug.getFlightRecorder()};
    }''',{'hi':(mask6>>7)&3,'lo':mask6&127})
    ons=[e for e in (race['fr'].get('events') or []) if e.get('type')=='semantic:note-on-sent']
    last=ons[-1] if ons else None
    check('C14 transition-window attack waits only the narrow 8ms sync',bool(last) and last['detail'].get('requestedRawSyncMs')==8, last['detail'] if last else race['live'])
    check('C15 transition-window attack resolves to fresh degree, avoiding stale low onset',bool(last) and str(last['detail'].get('degreeKey'))=='6' and str(race['live'].get('soundingDegreeKey'))=='6',{'note':last,'live':race['live']})
    page.evaluate(f'{dbg}.simulateMidi([0x82,57,64])'); page.wait_for_timeout(20); page.evaluate(f'{dbg}.stopFlightRecorder()')
  # Close-pitch precision: user's exact file.
  user_scl=pathlib.Path(scala_path).read_text()
  page.evaluate(f"async (t)=>{{await {dbg}.importText(t,'FirstideaTarsos.scl')}}",user_scl); page.wait_for_timeout(120)
  mapping=page.evaluate(f'{dbg}.getMapping()')
  rows={str(r.get('degreeKey')):r for r in mapping}
  a,b=rows['7'],rows['8']
  expected_delta=855.223880597015-852.5373134328358
  cents_delta=b['performanceCents']-a['performanceCents']
  ratio=b['targetFrequencyHz']/a['targetFrequencyHz']
  expected_ratio=2**(expected_delta/1200)
  check('C16 user close pair remains numerically distinct',abs(cents_delta-expected_delta)<1e-12 and a['targetFrequencyHz']!=b['targetFrequencyHz'],{'deltaCents':cents_delta,'freqA':a['targetFrequencyHz'],'freqB':b['targetFrequencyHz']})
  check('C17 close-pair frequency ratio matches exact cents math',abs(ratio-expected_ratio)<1e-12,{'ratio':ratio,'expected':expected_ratio})
  # Actually sound both adjacent degrees in the Reference Instrument via raw states.
  st=page.evaluate(f'{dbg}.getStates()')
  i7=next(x['index'] for x in st if str(x.get('sourceDegreeKey'))=='7')
  i8=next(x['index'] for x in st if str(x.get('sourceDegreeKey'))=='8')
  freqs=[]
  for idx,deg in [(i7,'7'),(i8,'8')]:
    page.evaluate(f'{dbg}.setDebugToneState({idx})'); page.evaluate(f'{dbg}.simulateMidi([0x92,57,100])'); page.wait_for_timeout(60)
    life=page.evaluate(f'{dbg}.getReferenceLifecycle()'); live=page.evaluate(f'{dbg}.getLiveState()')
    freqs.append({'degree':deg,'reference':life['currentFrequencyHz'],'logical':life['logicalFrequencyHz'],'sounding':live['soundingDegreeKey']})
    page.evaluate(f'{dbg}.simulateMidi([0x82,57,64])'); page.wait_for_timeout(25)
  check('C18 Reference Instrument renders both 2.6866-cent pitches separately',all(x['reference'] and x['logical'] and abs(x['reference']-x['logical'])<1e-8 for x in freqs) and abs(freqs[1]['reference']-freqs[0]['reference'])>1e-4,freqs)
  # Synthetic ultra-close precision: 1.0, 0.5, 0.1 cent distinctions must survive parse->mapping->frequency.
  synth='''! precision-gate.scl\nPrecision gate\n4\n500.0\n500.1\n500.5\n1200.0\n'''
  page.evaluate(f"async (t)=>{{await {dbg}.importText(t,'precision-gate.scl')}}",synth); page.wait_for_timeout(100)
  pm=page.evaluate(f'{dbg}.getMapping()')
  prs=[r for r in pm if not r.get('isPeriodClosure')]
  cents=[r['performanceCents'] for r in prs]
  # expected implicit 0 followed by 500,500.1,500.5
  close=[r for r in prs if 499.9 <= r['performanceCents'] <= 500.6]
  close=sorted(close,key=lambda r:r['performanceCents'])
  diffs=[close[i+1]['performanceCents']-close[i]['performanceCents'] for i in range(len(close)-1)]
  unique_freq=len({format(r['targetFrequencyHz'],'.15g') for r in close})==len(close)
  check('C19 0.1-cent source distinction survives internal mapping',len(close)==3 and abs(diffs[0]-0.1)<1e-10 and unique_freq,{'cents':[r['performanceCents'] for r in close],'freqs':[r['targetFrequencyHz'] for r in close],'diffs':diffs})
  # Separate 0.5 and 1.0 cent gate.
  synth2='''! precision-gate-2.scl\nPrecision gate 2\n4\n500.0\n500.5\n501.5\n1200.0\n'''
  page.evaluate(f"async (t)=>{{await {dbg}.importText(t,'precision-gate-2.scl')}}",synth2); page.wait_for_timeout(100)
  pm2=page.evaluate(f'{dbg}.getMapping()'); c2=sorted([r for r in pm2 if not r.get('isPeriodClosure') and 499.9<=r['performanceCents']<=501.6],key=lambda r:r['performanceCents'])
  d2=[c2[i+1]['performanceCents']-c2[i]['performanceCents'] for i in range(len(c2)-1)]
  check('C20 0.5- and 1.0-cent distinctions survive internal mapping',len(c2)==3 and abs(d2[0]-0.5)<1e-10 and abs(d2[1]-1.0)<1e-10 and len({format(r['targetFrequencyHz'],'.15g') for r in c2})==3,{'cents':[r['performanceCents'] for r in c2],'freqs':[r['targetFrequencyHz'] for r in c2],'diffs':d2})
  check('C21 no JavaScript page errors after full candidate gate',not errors,errors)
  check('C22 no console errors after full candidate gate',not console_errors,console_errors[:20])
  browser.close()
summary={'passes':sum(r['status']=='PASS' for r in results),'failures':sum(r['status']=='FAIL' for r in results),'total':len(results),'results':results}
pathlib.Path('/mnt/data/wsfl_rc1_work/evidence/rc1_candidate_browser_gate.json').write_text(json.dumps(summary,indent=2),encoding='utf8')
print(json.dumps({'passes':summary['passes'],'failures':summary['failures'],'total':summary['total']},indent=2))
for r in results:
    if r['status']=='FAIL': print('FAIL',r['name'],r['detail'])
sys.exit(1 if summary['failures'] else 0)
