from playwright.sync_api import sync_playwright
import json,re,math,sys,os
html='/mnt/data/WARBL_Scala_Fingering_Lab_v1_0_0_rc_1.html'
results=[]
def check(name, cond, detail=None):
    results.append({'name':name,'status':'PASS' if cond else 'FAIL','detail':detail})
    if not cond: print('FAIL',name,detail)
init=r'''(() => {
  let requestCount=0;
  try { Object.defineProperty(window,'isSecureContext',{configurable:true,value:true}); } catch(e) {}
  class MockPort { constructor(id,name,type){this.id=id;this.name=name;this.manufacturer='Mowry Stringed Instruments';this.type=type;this.state='connected';this.connection='closed';this.onmidimessage=null;this.sent=[];} async open(){this.connection='open';return this;} async close(){this.connection='closed';return this;} send(data){this.sent.push(Array.from(data));} }
  const input=new MockPort('warbl-in','WARBL MIDI 1','input'); const output=new MockPort('warbl-out','WARBL MIDI 1','output');
  const access={inputs:new Map([[input.id,input]]),outputs:new Map([[output.id,output]]),onstatechange:null};
  Object.defineProperty(navigator,'requestMIDIAccess',{configurable:true,value:async()=>{requestCount++;return access;}});
  try { Object.defineProperty(navigator,'permissions',{configurable:true,value:{query:async()=>({state:'granted',onchange:null})}}); } catch(e) {}
  window.__mockMidi={access,input,output,getRequestCount:()=>requestCount};
})();'''
with sync_playwright() as p:
  browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--autoplay-policy=no-user-gesture-required'])
  page=browser.new_page(viewport={'width':1440,'height':1000},accept_downloads=True)
  errors=[]; console_errors=[]
  page.on('pageerror',lambda e: errors.append(str(e)))
  page.on('console',lambda m: console_errors.append(m.text) if m.type=='error' else None)
  txt=open(html,encoding='utf8').read(); m=re.search(r'<script(?:\s[^>]*)?>(.*?)</script>',txt,re.S|re.I)
  page.set_content(txt[:m.start()]+'<script></script>'+txt[m.end():],wait_until='load',timeout=60000)
  page.evaluate(init); page.add_script_tag(content=m.group(1)); page.wait_for_timeout(700)
  dbg='window.WARBLScalaFingeringLaboratoryDebug'
  check('B01 page loads without JS errors',not errors,errors)
  check('B02 v1.0.0-rc.1 exact identity',page.evaluate(f'{dbg}.getState().status') is not None and 'v1.0.0-rc.1' in page.locator('footer.app-footer').inner_text())
  check('B03 Lab Fingering remains default',page.eval_on_selector('#performancePitchSource','e=>e.value')=='lab-raw')
  page.click('#connectMidi'); page.wait_for_timeout(250)
  ui=page.evaluate(f'{dbg}.getConnectionUi()')
  check('B04 one-click MIDI + Live Sensors remains active','Connected' in ui['midi'] and ui['sensors']=='Live Sensors: On',ui)
  # establish a known raw fingering and a non-zero pre-note bend anchor
  page.evaluate(f'{dbg}.setDebugToneState(0)'); page.wait_for_timeout(30)
  base=10000; page.evaluate(f'{dbg}.simulateMidi([0xE2,{base & 127},{base>>7}])'); page.wait_for_timeout(20)
  page.evaluate(f'{dbg}.simulateMidi([0x92,65,110])'); page.wait_for_timeout(80)
  live0=page.evaluate(f'{dbg}.getLiveExpressionCalculation()')
  check('B05 Lab Note On establishes local bend anchor',live0['rawExpressionAnchorCents'] is not None and abs(live0['appliedBendCents'])<1e-6,live0)
  # move bend by +100 14-bit units; verify against the configured incoming range via the actual expressive delta.
  nxt=10100; page.evaluate(f'{dbg}.simulateMidi([0xE2,{nxt & 127},{nxt>>7}])'); page.wait_for_timeout(30)
  live1=page.evaluate(f'{dbg}.getLiveExpressionCalculation()')
  expected=live1['expressiveBendCents']-live0['rawExpressionAnchorCents']
  check('B06 continuous bend stays local to raw-fingering anchor',abs(live1['appliedBendCents']-expected)<0.02,{'got':live1,'expected':expected})
  check('B07 reference synth target equals logical live frequency after bend',abs(live1['referenceFrequencyHz']-live1['soundingFrequencyHz'])<1e-6,live1)
  # same physical degree reconciliation must not create drift
  page.evaluate(f'{dbg}.setDebugToneState(0)'); page.wait_for_timeout(50)
  life=page.evaluate(f'{dbg}.getReferenceLifecycle()')
  check('B08 same-degree raw reconciliation preserves local bend',abs(life['currentFrequencyHz']-life['logicalFrequencyHz'])<1e-6,life)
  check('B09 audio sentinel remains coherent after raw/bend reconciliation',life['sentinel']['classification']=='coherent-owned-audio',life['sentinel'])
  page.evaluate(f'{dbg}.simulateMidi([0x82,65,64])'); page.wait_for_timeout(50)
  # Lab mismatch must not withhold notes.
  page.evaluate(f'{dbg}.setDebugToneState(255)'); page.evaluate(f'{dbg}.simulateMidi([0x92,57,100])'); page.wait_for_timeout(60)
  live2=page.evaluate(f'{dbg}.getLiveState()')
  check('B10 Lab Fingering still sounds despite device chart mismatch',live2['soundingDegreeKey'] is not None and live2['outputBlockedReason'] is None,live2)
  page.evaluate(f'{dbg}.simulateMidi([0x82,57,64])'); page.wait_for_timeout(50)
  # Automatic remains fail closed.
  page.evaluate(f"{dbg}.setPerformanceSources('auto','auto')"); page.evaluate(f'{dbg}.setDebugToneState(0)'); page.evaluate(f'{dbg}.simulateMidi([0x92,69,100])'); page.wait_for_timeout(70)
  au=page.evaluate(f'{dbg}.getAuthorityUi()')
  check('B11 Automatic verification remains fail-closed',au['blockReason'] is not None and 'CONFLICT' in au['automatic'],au)
  page.evaluate(f'{dbg}.simulateMidi([0x82,69,64])'); page.wait_for_timeout(40)
  page.evaluate(f"{dbg}.setPerformanceSources('lab-raw','auto')"); page.wait_for_timeout(30)
  # Pointer witness should name actual parent control even if nested STRONG is target.
  page.evaluate(f'{dbg}.clearFlightRecorder(); {dbg}.startFlightRecorder()')
  page.dispatch_event('#downloadPackage strong','pointerdown')
  page.wait_for_timeout(20)
  fr=page.evaluate(f'{dbg}.getFlightRecorder()')
  ptr=[e for e in (fr.get('events') or []) if e.get('type')=='browser-pointerdown']
  check('B12 pointer witness attributes nested text to interactive control',bool(ptr) and ptr[-1]['detail'].get('interactiveId')=='downloadPackage',ptr[-1]['detail'] if ptr else None)
  page.evaluate(f'{dbg}.stopFlightRecorder()')
  # Blocking UI boundary: release live state, establish stale fence, stale event cannot replay.
  page.evaluate(f'{dbg}.setDebugToneState(0)'); page.evaluate(f'{dbg}.simulateMidi([0x92,65,110])'); page.wait_for_timeout(50)
  before=page.evaluate(f'{dbg}.getLiveState()'); enter=page.evaluate(f"{dbg}.simulateBlockingUiEnter('debug print')")
  check('B13 blocking UI boundary releases live note',before['noteGate'] is True and enter['active'] is True and page.evaluate(f'{dbg}.getLiveState().noteGate') is False,{'beforeGate':before['noteGate'],'enter':enter})
  exit_state=page.evaluate(f"{dbg}.simulateBlockingUiExit('debug print')")
  fence=exit_state['ignoreMidiEventBefore']
  check('B14 blocking UI exit establishes stale MIDI fence',exit_state['active'] is False and fence>0,exit_state)
  page.evaluate('(args)=>handleMidiMessage({data:Uint8Array.from(args.data),timeStamp:args.ts})',{'data':[0x92,65,127],'ts':fence-1000})
  page.wait_for_timeout(40)
  check('B15 stale queued MIDI is discarded after blocking UI',page.evaluate(f'{dbg}.getLiveState().noteGate') is False,page.evaluate(f'{dbg}.getLiveState()'))
  # Async ZIP must be byte-identical to synchronous deterministic builder and yield at least once.
  zipcmp=page.evaluate('''async () => { const files=exportFiles(); const a=createStoredZip(files); let tick=false; setTimeout(()=>{tick=true;},0); const b=await createStoredZipAsync(files); const [ab,bb]=await Promise.all([a.arrayBuffer(),b.arrayBuffer()]); const x=new Uint8Array(ab), y=new Uint8Array(bb); let same=x.length===y.length; if(same){for(let i=0;i<x.length;i++){if(x[i]!==y[i]){same=false;break;}}} return {same,sizeA:x.length,sizeB:y.length,yielded:tick}; }''')
  check('B16 yielding ZIP is byte-identical to synchronous ZIP',zipcmp['same'] and zipcmp['sizeA']==zipcmp['sizeB'],zipcmp)
  check('B17 ZIP builder yields to event loop',zipcmp['yielded'] is True,zipcmp)
  # Source/geometry/status regressions from recovered.6 remain.
  page.evaluate(f'{dbg}.setDebugToneState(0)'); page.wait_for_timeout(40)
  markers=page.evaluate(f'{dbg}.getPitchGeometryLiveMarkers()')
  check('B18 Pitch Geometry physical witness remains present',str(markers['physicalDegreeKey']) in markers['physicalMarkedKeys'],markers)
  check('B19 notation boundary remains non-link callout',page.locator('.notation-boundary-callout').count()==1)
  check('B20 no page errors after integrated run',not errors,errors)
  check('B21 no console errors after integrated run',not console_errors,console_errors[:10])
  browser.close()
summary={'passes':sum(r['status']=='PASS' for r in results),'failures':sum(r['status']=='FAIL' for r in results),'results':results}
open('/mnt/data/rc1_inherited_browser.json','w').write(json.dumps(summary,indent=2))
print(json.dumps(summary,indent=2))
sys.exit(1 if summary['failures'] else 0)
