import re,json,hashlib,subprocess,os
r6='/mnt/data/WARBL_Scala_Fingering_Lab_v0_6_0_audit_12c_recovered_8.html'
r7='/mnt/data/WARBL_Scala_Fingering_Lab_v1_0_0_rc_1.html'
a=open(r6,encoding='utf-8').read(); b=open(r7,encoding='utf-8').read(); tests=[]
def add(name,ok,detail=None): tests.append({'name':name,'status':'PASS' if ok else 'FAIL','detail':detail})
def fn(src,name):
 m=re.search(r'(?:(?:async)\s+)?function\s+'+re.escape(name)+r'\s*\(',src)
 if not m:return None
 n=re.search(r'\n(?:(?:async)\s+)?function\s+[A-Za-z_$][\w$]*\s*\(',src[m.end():])
 stop=m.end()+n.start() if n else len(src)
 return src[m.start():stop]
def normver(x): return x.replace('v1.0.0-rc.1','v0.6.0-audit.12c-recovered.8') if x else x
script=re.search(r'<script(?:\s[^>]*)?>(.*?)</script>',b,re.S|re.I).group(1)
open('/mnt/data/wsfl_rc1_work/recovered8_script_sourcegate.js','w').write(script)
rc=subprocess.run(['node','--check','/mnt/data/wsfl_rc1_work/recovered8_script_sourcegate.js'],capture_output=True,text=True)
add('S01 JavaScript syntax',rc.returncode==0,rc.stderr.strip())
add('S02 v1.0.0-rc.1 current identity present', 'v1.0.0-rc.1' in b)
# recovered.6 workflow protections retained
add('S03 Lab Fingering remains default performance authority',"performancePitchSource: 'lab-raw'" in b)
add('S04 Lab Fingering remains selected UI source',re.search(r'<option value="lab-raw" selected>',b)!=None)
add('S05 Automatic remains verification mode','Automatic verification — compare device MIDI + Lab fingering' in b)
add('S06 separate Live Sensors witness retained','id="sensorConnection"' in b)
add('S07 Connect idempotence retained','if (state.midiAccess)' in (fn(b,'requestMidi') or ''))
add('S08 setup-read sensor pause/resume retained','resumeSensorMonitorAfterRead' in b and 'stopWarblSensorMonitor({ announce: false })' in b)
add('S09 Pitch Geometry physical-observed marker retained','.wheel-degree.physical-observed' in b and "classList.toggle('physical-observed'" in b)
add('S10 output block reason specificity retained','function outputBlockLabel(reason)' in b and 'blocked · authority conflict' in b and 'blocked · no exact anchor' in b)
add('S11 notation boundary remains non-link callout','class="notation-boundary-callout"' in b)
# New expression fixes
la=fn(b,'liveAppliedExpressionCents') or ''
ue=fn(b,'updateLiveExpressionFrequencyFromCurrentBend') or ''
hm=fn(b,'handleMidiMessage') or ''
cr=fn(b,'correctLiveOutputAfterFreshHoleState') or ''
add('S12 local-expression helper exists','rawExpressionAnchorCents' in la and 'return expressive - Number(anchor || 0)' in la)
add('S13 pitch-bend hot path uses shared local-expression helper','updateLiveExpressionFrequencyFromCurrentBend()' in hm)
add('S14 pitch-bend hot path no longer directly assigns absolute applied bend','state.live.appliedBendCents = Number(state.live.expressiveBendCents || 0)' not in hm)
add('S15 pitch-bend updates legacy mirror for bend-before-Note-On','state.expressiveBendCents = state.live.expressiveBendCents' in hm)
add('S16 fresh lab-raw attack invalidates old anchor before reconciliation','liveGateWasOpen' in hm and 'state.live.rawExpressionAnchorCents = null' in hm and "performancePitchSource === 'lab-raw'" in hm)
add('S17 local helper requires anchor degree to match physical degree','String(anchorKey) !== String(physicalKey)' in la)
add('S18 expression helper computes logical frequency from applied local cents','Math.pow(2, applied / 1200)' in ue)
add('S19 fresh-hole correction detects same-degree synth/logical divergence','referenceNeedsSync' in cr and 'live-frequency-reconciliation' in cr)
add('S20 external retrigger remains degree-change-only','else if (degreeChanged && state.live.outputSourceKey && state.midiOutput)' in cr)
# Blocking UI + ZIP fixes
cz=fn(b,'createStoredZipAsync') or ''
pu=fn(b,'pauseRealtimeForBlockingUi') or ''
ru=fn(b,'resumeRealtimeAfterBlockingUi') or ''
ib=fn(b,'installBlockingUiBoundaries') or ''
add('S21 yielding ZIP builder exists','await yieldToRealtimePath()' in cz and 'await crc32Async' in cz)
add('S22 synchronous ZIP builder retained for deterministic parity','function createStoredZip(' in b)
add('S23 Project Export uses async yielding ZIP','await createStoredZipAsync(files)' in b)
add('S24 Project Export records start and completion witnesses','project-export-zip-start' in b and 'project-export-zip-complete' in b)
add('S25 blocking UI enter releases reference audio','releaseAudioOwner' in pu and 'state.live.noteGate = false' in pu)
add('S26 blocking UI enter closes external live voices','stopAll(reason)' in pu)
add('S27 blocking UI exit establishes stale-event fence','ignoreMidiEventBefore = now' in ru)
add('S28 MIDI handler drops stale browser-queued messages before mutation','midi-stale-after-blocking-ui-dropped' in hm and hm.find('midi-stale-after-blocking-ui-dropped') < hm.find('state.midiDiagnostics.eventCount += 1'))
add('S29 beforeprint/afterprint boundaries installed',"addEventListener('beforeprint'" in ib and "addEventListener('afterprint'" in ib)
add('S30 print control explains realtime pause','Printing temporarily pauses live performance' in b)
# Trace attribution
obs=fn(b,'installAudit8BrowserObservers') or ''
add('S31 pointer witness records interactive ancestor','interactiveId' in obs and 'interactiveTag' in obs and 'interactiveText' in obs)
add('S32 interactive text is bounded','slice(0, 120)' in obs)
# Core truth/math unchanged from recovered.6, normalizing build version where needed
core=['parseScalaValue','parseScala','compileWarbl256','compileFieldOperatorLayers','activeDeviceChartVerification','automaticAuthorityConsistency','mappingRowByKey','applyFieldData','sourceMappingRows','compileCurrentFieldOperators','currentScaleSclText','playableFieldSclText','buildProjectExportSnapshot','exactMidiMappingResolution','sendRetunedNote','installOnWarbl','sceneCommand','truthManifest']
for idx,name in enumerate(core,33):
 fa,fb=fn(a,name),fn(b,name)
 same=fa is not None and normver(fb)==fa
 add(f'S{idx:02d} core function unchanged except build identity: {name}',same,None if same else 'body differs or missing')
# There are 50 above exactly S01-S50.
sha=hashlib.sha256(open(r7,'rb').read()).hexdigest(); parent=hashlib.sha256(open(r6,'rb').read()).hexdigest()
out={'source':os.path.basename(r7),'sha256':sha,'parentSha256':parent,'tests':tests,'summary':{'pass':sum(t['status']=='PASS' for t in tests),'fail':sum(t['status']=='FAIL' for t in tests),'total':len(tests)}}
open('/mnt/data/rc1_source_regression.json','w').write(json.dumps(out,indent=2))
print(json.dumps(out['summary'],indent=2))
for t in tests:
 if t['status']=='FAIL': print('FAIL',t['name'],t['detail'])
raise SystemExit(1 if out['summary']['fail'] else 0)
