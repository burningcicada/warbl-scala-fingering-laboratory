from playwright.sync_api import sync_playwright
import json, os, time, re
html='/mnt/data/WARBL_Scala_Fingering_Lab_v1_0_0_rc_1.html'
results=[]
def check(name, cond, detail=None):
    results.append({'name':name,'status':'PASS' if cond else 'FAIL','detail':detail})
    if not cond:
        print('FAIL',name,detail)

init=r'''
(() => {
  let requestCount=0;
  try { Object.defineProperty(window,'isSecureContext',{configurable:true,value:true}); } catch(e) {}
  class MockPort {
    constructor(id,name,type){this.id=id;this.name=name;this.manufacturer='Mowry Stringed Instruments';this.type=type;this.state='connected';this.connection='closed';this.onmidimessage=null;this.sent=[];}
    async open(){this.connection='open';return this;}
    async close(){this.connection='closed';return this;}
    send(data){this.sent.push(Array.from(data));}
  }
  const input=new MockPort('warbl-in','WARBL MIDI 1','input');
  const output=new MockPort('warbl-out','WARBL MIDI 1','output');
  const access={inputs:new Map([[input.id,input]]),outputs:new Map([[output.id,output]]),onstatechange:null};
  Object.defineProperty(navigator,'requestMIDIAccess',{configurable:true,value:async()=>{requestCount++;return access;}});
  try { Object.defineProperty(navigator,'permissions',{configurable:true,value:{query:async()=>({state:'granted',onchange:null})}}); } catch(e) {}
  window.__mockMidi={access,input,output,getRequestCount:()=>requestCount};
})();
'''
with sync_playwright() as p:
    browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--autoplay-policy=no-user-gesture-required'])
    page=browser.new_page(viewport={'width':1440,'height':1000})
    errors=[]; console_errors=[]
    page.on('pageerror',lambda e: errors.append(str(e)))
    page.on('console',lambda m: console_errors.append(m.text) if m.type=='error' else None)
    page.goto('about:blank')
    html_text=open(html,encoding='utf-8').read()
    m=re.search(r'<script(?:\s[^>]*)?>(.*?)</script>',html_text,re.S|re.I)
    script=m.group(1)
    html_shell=html_text[:m.start()]+'<script></script>'+html_text[m.end():]
    page.set_content(html_shell,wait_until='load',timeout=60000)
    page.evaluate(init)
    page.add_script_tag(content=script)
    page.wait_for_timeout(700)
    check('B01 page loads without JS errors',not errors,errors)
    check('B02 default pitch source is Lab Fingering',page.eval_on_selector('#performancePitchSource','e=>e.value')=='lab-raw',page.eval_on_selector('#performancePitchSource','e=>e.value'))
    check('B03 notation boundary is non-link instruction callout',page.locator('.notation-boundary-callout').count()==1 and page.locator('.resource-note').filter(has_text='Notation rendering boundary').count()==0)
    check('B04 separate MIDI and sensor status exists',page.locator('#midiConnection').count()==1 and page.locator('#sensorConnection').count()==1,page.evaluate('window.WARBLScalaFingeringLaboratoryDebug.getConnectionUi()'))
    # Connect: first request + sensor auto-start.
    page.click('#connectMidi')
    page.wait_for_timeout(250)
    ui=page.evaluate('window.WARBLScalaFingeringLaboratoryDebug.getConnectionUi()')
    req1=page.evaluate('window.__mockMidi.getRequestCount()')
    check('B05 first Connect grants/selects WARBL MIDI', 'Connected' in ui['midi'] and req1==1, {'ui':ui,'requests':req1})
    check('B06 Lab default auto-starts Live Sensors after Connect', ui['sensors']=='Live Sensors: On' and 'Stop Live' in ui['monitorButton'],ui)
    # second Connect must be idempotent and not re-prompt/re-request
    page.click('#connectMidi'); page.wait_for_timeout(160)
    ui2=page.evaluate('window.WARBLScalaFingeringLaboratoryDebug.getConnectionUi()'); req2=page.evaluate('window.__mockMidi.getRequestCount()')
    check('B07 Connect is idempotent after access',req2==1 and 'Rescan' in ui2['connectButton'] and 'Connected' in ui2['midi'],{'ui':ui2,'requests':req2})
    # Physical geometry witness independent of sound.
    fixture=page.evaluate('window.WARBLScalaFingeringLaboratoryDebug.setDebugToneState(0)')
    page.wait_for_timeout(80)
    markers=page.evaluate('window.WARBLScalaFingeringLaboratoryDebug.getPitchGeometryLiveMarkers()')
    check('B08 Pitch Geometry follows physical fingering independently',str(markers['physicalDegreeKey']) in markers['physicalMarkedKeys'] and markers['soundingDegreeKey'] is None,markers)
    # Lab authority must sound from raw fingering even if incoming MIDI lacks exact anchor.
    page.evaluate('window.WARBLScalaFingeringLaboratoryDebug.simulateMidi([0x90,57,100])')
    page.wait_for_timeout(120)
    live=page.evaluate('window.WARBLScalaFingeringLaboratoryDebug.getLiveState()')
    check('B09 Lab Fingering plays raw Working degree despite unmatched incoming MIDI anchor',live['soundingDegreeKey'] is not None and live['outputBlockedReason'] is None,{'degree':live['soundingDegreeKey'],'blocked':live['outputBlockedReason']})
    page.evaluate('window.WARBLScalaFingeringLaboratoryDebug.simulateMidi([0x80,57,64])'); page.wait_for_timeout(80)
    # Automatic remains verification and idle says READY.
    page.evaluate("window.WARBLScalaFingeringLaboratoryDebug.setPerformanceSources('auto','auto')")
    page.wait_for_timeout(80)
    au=page.evaluate('window.WARBLScalaFingeringLaboratoryDebug.getAuthorityUi()')
    check('B10 Automatic idle is READY not failure-language', 'Automatic verification' in au['automatic'] and 'READY' in au['automatic'] and 'UNAVAILABLE' not in au['automatic'],au)
    # Create a conflict and verify exact label.
    page.evaluate('window.WARBLScalaFingeringLaboratoryDebug.setDebugToneState(0)'); page.wait_for_timeout(40)
    page.evaluate('window.WARBLScalaFingeringLaboratoryDebug.simulateMidi([0x90,69,100])'); page.wait_for_timeout(100)
    au2=page.evaluate('window.WARBLScalaFingeringLaboratoryDebug.getAuthorityUi()')
    check('B11 Automatic conflict remains fail-closed',au2['blockReason'] is not None and 'AUTHORITY CONFLICT' in au2['blockReason'] and 'CONFLICT' in au2['automatic'],au2)
    check('B12 blocked witness reports actual authority reason',au2['mpeWitness']=='blocked · authority conflict',au2)
    page.evaluate('window.WARBLScalaFingeringLaboratoryDebug.simulateMidi([0x80,69,64])'); page.wait_for_timeout(60)
    # Switch back to lab should retain selection and auto-start sensors if needed.
    page.evaluate("document.querySelector('#performancePitchSource').value='lab-raw'; document.querySelector('#performancePitchSource').dispatchEvent(new Event('change',{bubbles:true}))")
    page.wait_for_timeout(100)
    au3=page.evaluate('window.WARBLScalaFingeringLaboratoryDebug.getAuthorityUi()'); ui3=page.evaluate('window.WARBLScalaFingeringLaboratoryDebug.getConnectionUi()')
    check('B13 switching to Lab Fingering is not blocked',au3['source']=='lab-raw' and ui3['sensors']=='Live Sensors: On',{'authority':au3,'ui':ui3})
    # Read setup should auto-pause live sensors instead of rejecting.
    page.evaluate("document.querySelector('#readWarbl').click()"); page.wait_for_timeout(120)
    tr=page.evaluate('window.WARBLScalaFingeringLaboratoryDebug.getWarblReadTransport()'); ui4=page.evaluate('window.WARBLScalaFingeringLaboratoryDebug.getConnectionUi()')
    check('B14 Read Setup auto-pauses Live Sensors for exclusive transaction',tr['transaction'] is True and tr['sensorMonitorActive'] is False and 'Paused for setup read' in ui4['sensors'],{'transport':tr,'ui':ui4})
    # supply a valid WARBL response so auto-exit occurs, then verify resume.
    page.evaluate('window.WARBLScalaFingeringLaboratoryDebug.simulateConfig([0xB6,110,47])')
    page.wait_for_timeout(1750)
    tr2=page.evaluate('window.WARBLScalaFingeringLaboratoryDebug.getWarblReadTransport()'); ui5=page.evaluate('window.WARBLScalaFingeringLaboratoryDebug.getConnectionUi()')
    check('B15 Read Setup automatically resumes Live Sensors',tr2['sensorMonitorActive'] is True and ui5['sensors']=='Live Sensors: On',{'transport':tr2,'ui':ui5})
    # Automatic no-exact-anchor label distinct from chart mismatch.
    page.evaluate("window.WARBLScalaFingeringLaboratoryDebug.setPerformanceSources('auto','auto')"); page.evaluate('window.WARBLScalaFingeringLaboratoryDebug.setDebugToneState(255)'); page.wait_for_timeout(50)
    page.evaluate('window.WARBLScalaFingeringLaboratoryDebug.simulateMidi([0x90,57,100])'); page.wait_for_timeout(80)
    au4=page.evaluate('window.WARBLScalaFingeringLaboratoryDebug.getAuthorityUi()')
    check('B16 no-exact-anchor block label is specific',au4['mpeWitness']=='blocked · no exact anchor' and 'NO EXACT ANCHOR' in au4['automatic'] and 'UNAVAILABLE' not in au4['automatic'],au4)
    # No console errors produced by run.
    check('B17 browser run has no page errors',not errors,errors)
    check('B18 browser run has no console errors',not console_errors,console_errors[:10])
    browser.close()

summary={'passes':sum(r['status']=='PASS' for r in results),'failures':sum(r['status']=='FAIL' for r in results),'results':results}
open('/mnt/data/rc1_workflow.json','w').write(json.dumps(summary,indent=2))
print(json.dumps(summary,indent=2))
raise SystemExit(1 if summary['failures'] else 0)
