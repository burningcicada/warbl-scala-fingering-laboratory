import re,json,sys,statistics
from pathlib import Path
from playwright.sync_api import sync_playwright

paths={
 'recovered7':'/mnt/data/WARBL_Scala_Fingering_Lab_v0_6_0_audit_12c_recovered_7.html',
 'recovered8':'/mnt/data/WARBL_Scala_Fingering_Lab_v1_0_0_rc_1.html',
}
init=r'''(() => {
  try { Object.defineProperty(window,'isSecureContext',{configurable:true,value:true}); } catch(e) {}
  class MockPort { constructor(id,name,type){this.id=id;this.name=name;this.manufacturer='Mowry Stringed Instruments';this.type=type;this.state='connected';this.connection='closed';this.onmidimessage=null;this.sent=[];} async open(){this.connection='open';return this;} async close(){this.connection='closed';return this;} send(data){this.sent.push(Array.from(data));} }
  const input=new MockPort('warbl-in','WARBL MIDI 1','input'); const output=new MockPort('warbl-out','WARBL MIDI 1','output');
  const access={inputs:new Map([[input.id,input]]),outputs:new Map([[output.id,output]]),onstatechange:null};
  Object.defineProperty(navigator,'requestMIDIAccess',{configurable:true,value:async()=>access});
  try { Object.defineProperty(navigator,'permissions',{configurable:true,value:{query:async()=>({state:'granted',onchange:null})}}); } catch(e) {}
})();'''

def load(page,path):
    txt=Path(path).read_text(encoding='utf8'); m=re.search(r'<script(?:\s[^>]*)?>(.*?)</script>',txt,re.S|re.I)
    page.set_content(txt[:m.start()]+'<script></script>'+txt[m.end():],wait_until='load',timeout=60000)
    page.evaluate(init); page.add_script_tag(content=m.group(1)); page.wait_for_timeout(500)
    page.click('#connectMidi'); page.wait_for_timeout(100)

def drift_fixture(page):
    # Establish a live lab-raw note and then reproduce the architectural drift pattern:
    # degree change rebases bend; a later bend moves locally; a same-degree raw reconcile follows.
    return page.evaluate('''async () => {
      const D=window.WARBLScalaFingeringLaboratoryDebug;
      D.setDebugToneState(0);
      await D.simulateMidi([0xE2, 10000 & 127, 10000 >> 7]);
      await D.simulateMidi([0x92,65,110]);
      await new Promise(r=>setTimeout(r,20));
      await D.simulateMidi([0xE2, 10100 & 127, 10100 >> 7]);
      const calc=()=>({expressiveBendCents:Number(state.live.expressiveBendCents||0),appliedBendCents:Number(state.live.appliedBendCents||0),rawExpressionAnchorCents:state.live.rawExpressionAnchorCents,rawExpressionAnchorDegreeKey:state.live.rawExpressionAnchorDegreeKey,rawExpressionDeltaCents:Number(state.live.rawExpressionDeltaCents||0),soundingFrequencyHz:state.live.soundingFrequencyHz,referenceFrequencyHz:Number.isFinite(Number(state.synth?.current?.frequency))?Number(state.synth.current.frequency):null});
      const beforeChange=calc();
      const prev=state.live.soundingDegreeKey;
      // physical degree changes to tone state 255; run the actual correction hook explicitly
      D.setDebugToneState(255);
      correctLiveOutputAfterFreshHoleState(prev,'perf degree change');
      const afterChange=calc();
      await D.simulateMidi([0xE2, 10120 & 127, 10120 >> 7]);
      const afterBend=calc();
      const samePrev=state.live.soundingDegreeKey;
      // same physical degree arrives again, as happens in dense raw sensor traffic
      state.live.holeStateRevision += 1;
      state.live.lastHoleStateAt=performance.now();
      reconcileLivePerformanceState('perf same-degree raw refresh');
      correctLiveOutputAfterFreshHoleState(samePrev,'perf same-degree raw refresh');
      const afterRefresh=calc();
      const sentinel=D.getReferenceLifecycle().sentinel;
      await D.simulateMidi([0x82,65,64]);
      return {beforeChange,afterChange,afterBend,afterRefresh,sentinel};
    }''')

def bend_stress(page,count=5000):
    return page.evaluate('''async (count) => {
      const D=window.WARBLScalaFingeringLaboratoryDebug;
      D.setDebugToneState(0);
      await D.simulateMidi([0x92,65,110]);
      const before=D.getAudit12cCounters();
      const structuralBefore=JSON.stringify({mapping:D.getMapping(),scl:D.getCurrentScaleScl()});
      const t0=performance.now();
      for(let i=0;i<count;i++){
        const v=8192 + ((i%201)-100);
        handleMidiMessage({data:Uint8Array.from([0xE2,v&127,(v>>7)&127]),timeStamp:performance.now()});
      }
      const elapsed=performance.now()-t0;
      const after=D.getAudit12cCounters();
      const structuralAfter=JSON.stringify({mapping:D.getMapping(),scl:D.getCurrentScaleScl()});
      const life=D.getReferenceLifecycle();
      await D.simulateMidi([0x82,65,64]);
      return {count,elapsed,perEventUs:elapsed*1000/count,before,after,structuralSame:structuralBefore===structuralAfter,sentinel:life.sentinel,expression:{expressiveBendCents:Number(state.live.expressiveBendCents||0),appliedBendCents:Number(state.live.appliedBendCents||0),soundingFrequencyHz:state.live.soundingFrequencyHz,referenceFrequencyHz:Number.isFinite(Number(state.synth?.current?.frequency))?Number(state.synth.current.frequency):null}};
    }''',count)

out={'tests':[],'comparative':{}}
with sync_playwright() as p:
    browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--autoplay-policy=no-user-gesture-required'])
    for name,path in paths.items():
        page=browser.new_page(viewport={'width':1440,'height':1000})
        errors=[]; page.on('pageerror',lambda e,errors=errors: errors.append(str(e)))
        load(page,path)
        d=drift_fixture(page)
        s=bend_stress(page)
        out['comparative'][name]={'driftFixture':d,'bendStress':s,'errors':errors}
        page.close()
    browser.close()

r7=out['comparative']['recovered7']; r8=out['comparative']['recovered8']
def add(name,ok,detail=None): out['tests'].append({'name':name,'status':'PASS' if ok else 'FAIL','detail':detail})
r7s=r7['driftFixture']['sentinel']; r8s=r8['driftFixture']['sentinel']
add('P01 recovered.7 physical-parent fixture remains coherent',r7s.get('classification')=='coherent-owned-audio',r7s)
add('P02 recovered.8 same local-bend/raw-refresh fixture remains coherent',r8s.get('classification')=='coherent-owned-audio',r8s)
add('P03 recovered.8 logical and reference Hz agree after same-degree raw refresh',abs((r8['driftFixture']['afterRefresh']['referenceFrequencyHz'] or 0)-(r8['driftFixture']['afterRefresh']['soundingFrequencyHz'] or 0))<1e-6,r8['driftFixture']['afterRefresh'])
add('P04 recovered.8 bend stress causes zero Mapping Capacity runs',r8['bendStress']['before']==r8['bendStress']['after'],{'before':r8['bendStress']['before'],'after':r8['bendStress']['after']})
add('P05 recovered.8 bend stress preserves structural fingerprint',r8['bendStress']['structuralSame'],None)
add('P06 recovered.8 bend stress sentinel remains coherent',r8['bendStress']['sentinel'].get('classification')=='coherent-owned-audio',r8['bendStress']['sentinel'])
add('P07 recovered.8 5000 bend handlers stay sub-0.10 ms average',r8['bendStress']['perEventUs']<100,r8['bendStress'])
add('P08 no browser JS errors in parent/candidate comparative fixture',not r7['errors'] and not r8['errors'],{'r7':r7['errors'],'r8':r8['errors']})
out['summary']={'pass':sum(t['status']=='PASS' for t in out['tests']),'fail':sum(t['status']=='FAIL' for t in out['tests']),'total':len(out['tests'])}
Path('/mnt/data/wsfl_rc1_work/evidence/rc1_performance_regression.json').write_text(json.dumps(out,indent=2))
print(json.dumps({'summary':out['summary'],'candidatePerEventUs':r8['bendStress']['perEventUs']},indent=2))
sys.exit(1 if out['summary']['fail'] else 0)
