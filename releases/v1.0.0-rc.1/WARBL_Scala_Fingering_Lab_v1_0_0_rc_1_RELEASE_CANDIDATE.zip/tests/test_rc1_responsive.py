from playwright.sync_api import sync_playwright
import re,json,hashlib
html='/mnt/data/WARBL_Scala_Fingering_Lab_v1_0_0_rc_1.html'
text=open(html,encoding='utf-8').read(); m=re.search(r'<script(?:\s[^>]*)?>(.*?)</script>',text,re.S|re.I); script=m.group(1); shell=text[:m.start()]+'<script></script>'+text[m.end():]
widths=[360,390,480,768,1024,1280,1440,1920]; tests=[]; all_errors=[]
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
 for w in widths:
  page=b.new_page(viewport={'width':w,'height':1200}); errs=[]; page.on('pageerror',lambda e,errs=errs: errs.append(str(e)))
  page.set_content(shell,wait_until='load'); page.add_script_tag(content=script); page.wait_for_timeout(250)
  d=page.evaluate('''() => ({innerWidth:innerWidth,docWidth:document.documentElement.scrollWidth,bodyWidth:document.body.scrollWidth,main:Math.round(document.querySelector('main').getBoundingClientRect().width),callout:Math.round(document.querySelector('.notation-boundary-callout').getBoundingClientRect().width)})''')
  ok=d['docWidth']<=w and d['bodyWidth']<=w and d['callout']<=d['main']+1 and not errs
  tests.append({'name':f'R{w} responsive containment','status':'PASS' if ok else 'FAIL','detail':{**d,'errors':errs}}); all_errors.extend(errs); page.close()
 b.close()
out={'source':html.split('/')[-1],'sha256':hashlib.sha256(open(html,'rb').read()).hexdigest(),'tests':tests,'errors':all_errors,'summary':{'pass':sum(t['status']=='PASS' for t in tests),'fail':sum(t['status']=='FAIL' for t in tests),'total':len(tests)}}
open('/mnt/data/rc1_responsive.json','w').write(json.dumps(out,indent=2)); print(json.dumps(out,indent=2))
raise SystemExit(1 if out['summary']['fail'] else 0)
