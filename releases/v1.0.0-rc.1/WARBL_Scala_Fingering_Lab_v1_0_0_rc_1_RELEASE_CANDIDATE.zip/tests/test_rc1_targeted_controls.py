from playwright.sync_api import sync_playwright
import re,pathlib,json,sys,time
html='/mnt/data/WARBL_Scala_Fingering_Lab_v1_0_0_rc_1.html'
txt=pathlib.Path(html).read_text(); m=re.search(r'<script(?:\s[^>]*)?>(.*?)</script>',txt,re.S|re.I)
init=r'''(() => {
try{Object.defineProperty(window,'isSecureContext',{configurable:true,value:true});}catch(e){}
window.__clip=[]; window.confirm=()=>true; window.alert=()=>{}; window.prompt=(m,d)=>d||''; window.print=()=>{};
try{Object.defineProperty(navigator,'clipboard',{configurable:true,value:{writeText:async(t)=>{window.__clip.push(String(t));}}})}catch(e){}
})();'''
res={}
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--autoplay-policy=no-user-gesture-required'])
 page=b.new_page(accept_downloads=True)
 errs=[]; page.on('pageerror',lambda e:errs.append(str(e)))
 page.set_content(txt[:m.start()]+'<script></script>'+txt[m.end():],wait_until='load',timeout=60000)
 page.evaluate(init); page.add_script_tag(content=m.group(1)); page.wait_for_timeout(500)
 # copy 256 values fresh page
 page.click('#copyWarbl'); page.wait_for_timeout(100)
 clip=page.evaluate('window.__clip.slice()')
 lines=clip[-1].strip().splitlines() if clip else []
 res['copyWarbl']={'clipboardWrites':len(clip),'lineCount':len(lines),'allIntegers': all(x.strip().lstrip('-').isdigit() for x in lines),'status':page.locator('#status').inner_text() if page.locator('#status').count() else ''}
 # installer fresh state, chart-only. Directly set physical prerequisites and mock config output.
 prep=page.evaluate('''() => {
   const events = laboratoryDebug.attachMockWarblConfigOutput();
   state.midiInput={id:'warbl-debug-input',name:'WARBL Debug Input',manufacturer:'test',state:'connected',connection:'open'};
   state.device.firmwareVersion=47; state.device.model='WARBL2'; state.device.currentInstrument=2; state.device.hasReceivedState=true;
   document.querySelector('#installAssignmentMode').value='chart-only'; document.querySelector('#customChartSlot').value='1';
   return {validation:state.validation?.valid, states:state.states256.length, firmware:state.device.firmwareVersion, model:state.device.model};
 }''')
 page.evaluate('''() => { setTimeout(() => handleWarblConfigMessage(0xB6, WARBL_CC.CUSTOM, WARBL_ACK_CUSTOM), 2350); }''')
 page.click('#installWarbl')
 page.wait_for_timeout(2900)
 install=page.evaluate('''() => ({events: state.warblConfigOutput?.sent ?? null, debugEvents: null, status:document.querySelector('#installStatus')?.textContent||'', globalStatus:document.querySelector('#status')?.textContent||'', installed:state.device.sessionInstalledCharts[1]||null})''')
 # mock output events are closed-over; use send count by replacing function wrapper isn't exposed. infer from installed plus event count via a second wrapper property
 # attachMockWarblConfigOutput's events are returned but cannot cross-reference later; store on window before sends by override.
 res['installPrep']=prep
 res['installWarbl']={'status':install['status'],'globalStatus':install['globalStatus'],'installed':bool(install['installed']),'signature':install['installed']['signature'] if install['installed'] else None}
 res['pageErrors']=errs
 b.close()
res['pass']= (res['copyWarbl']['clipboardWrites']>=1 and res['copyWarbl']['lineCount']==256 and res['copyWarbl']['allIntegers'] and res['installWarbl']['installed'] and 'acknowledged' in res['installWarbl']['globalStatus'].lower() and not res['pageErrors'])
path='/mnt/data/wsfl_rc1_work/evidence/rc1_targeted_controls.json'; pathlib.Path(path).write_text(json.dumps(res,indent=2))
print(json.dumps(res,indent=2)); sys.exit(0 if res['pass'] else 1)
