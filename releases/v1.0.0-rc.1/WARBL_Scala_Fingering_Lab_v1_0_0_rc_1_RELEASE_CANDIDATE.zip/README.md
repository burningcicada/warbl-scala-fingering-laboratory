# WARBL Scala Fingering Laboratory v1.0.0-rc.1

This package is a software-verified release candidate for physical WARBL2 acceptance testing.

Open `WARBL_Scala_Fingering_Lab_v1_0_0_rc_1.html` directly in a compatible browser with Web MIDI support.

Read `BUILD_MANIFEST.md`, `SIMULATION_RESULTS.md`, and `PHYSICAL_TEST_PLAN.md` before interpreting the build as accepted. The RC is not yet labeled PHYSICALLY VERIFIED.
